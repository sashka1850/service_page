import { config, prices, services, offers, team, getPrice } from './data.js';
const $ = (selector) => document.querySelector(selector);
const money = (value) => new Intl.NumberFormat('ru-RU', { style: 'currency', currency: 'RUB', maximumFractionDigits: 0 }).format(value);
const escape = (value) => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
$('#services-list').innerHTML = services.map(s => `<article class="service-card"><span class="card-number">${s.icon} /</span><h3>${escape(s.title)}</h3><p>${escape(s.text)}</p><a href="${s.target}" ${s.target === '#contacts' ? `data-service="${escape(s.title)}"` : ''}>${escape(s.action)} <span>↗</span></a></article>`).join('');
$('#offers-list').innerHTML = offers.map((s, i) => `<article class="offer-card"><span class="card-number">0${i + 1} /</span><h3>${escape(s.title)}</h3><strong>${money(s.price)}</strong><ul>${s.items.map(item => `<li>${escape(item)}</li>`).join('')}</ul><a class="button light-button" href="#contacts" data-service="${escape(s.title)}">Обсудить диагностику <span>↗</span></a></article>`).join('');
$('#team-list').innerHTML = team.map(s => `<article class="team-card"><img src="./assets/${escape(s.image)}" alt="Временное фото для карточки: ${escape(s.name)}" loading="lazy"><p class="team-role">${escape(s.role)}</p><h3>${escape(s.name)}</h3><p>${escape(s.text)}</p></article>`).join('');
const brand = $('#brand'), model = $('#model');
Object.keys(prices).forEach(name => brand.add(new Option(name, name)));
function updatePrice() {
  const value = getPrice(brand.value, model.value);
  $('#price').textContent = value === null ? '—' : money(value);
  $('#price-note').textContent = value === null ? 'Выберите ваш автомобиль' : `${brand.value} ${model.value} · предварительный расчёт`;
}
brand.addEventListener('change', () => {
  model.replaceChildren(new Option(brand.value ? 'Выберите модель' : 'Сначала выберите марку', ''));
  model.disabled = !brand.value;
  if (brand.value) Object.keys(prices[brand.value]).forEach(name => model.add(new Option(name, name)));
  updatePrice();
});
model.addEventListener('change', updatePrice);
$('#calculator-form').addEventListener('submit', event => {
  event.preventDefault();
  const value = getPrice(brand.value, model.value);
  if (value === null) return;
  $('#selected-service').textContent = `Ваш выбор: ТО ${brand.value} ${model.value}. Предварительно ${money(value)}. Запись ещё не оформлена.`;
  location.hash = 'contacts';
});
document.querySelectorAll('[data-service]').forEach(link => link.addEventListener('click', () => {
  $('#selected-service').textContent = `Вас интересует: ${link.dataset.service}. Запись ещё не оформлена.`;
}));
const menuButton = $('.menu-toggle'), navigation = $('#navigation');
function closeMenu() { menuButton.setAttribute('aria-expanded', 'false'); navigation.classList.remove('is-open'); }
menuButton.addEventListener('click', () => {
  const open = menuButton.getAttribute('aria-expanded') !== 'true';
  menuButton.setAttribute('aria-expanded', String(open)); navigation.classList.toggle('is-open', open);
});
navigation.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
const contactLinks = [];
if (/^\+[1-9]\d{7,14}$/.test(config.phone)) contactLinks.push({href: `tel:${config.phone}`, text: config.phone});
if (/^https:\/\/t\.me\/[a-zA-Z0-9_]+$/.test(config.telegram)) contactLinks.push({href: config.telegram, text: 'Написать в Telegram'});
for (const item of contactLinks) { const a = document.createElement('a'); a.className = 'button primary'; a.href = item.href; a.textContent = item.text; $('#contact-actions').append(a); }
if (contactLinks.length) $('#contact-status').textContent = 'Свяжитесь с нами, чтобы уточнить стоимость и время визита.';
$('.contact-card > p').textContent = [config.address, config.house, config.hours].filter(Boolean).join(' · ');
$('#year').textContent = new Date().getFullYear();
if (config.heroVideo && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const video = $('.hero-video'); video.src = config.heroVideo;
  video.addEventListener('playing', () => { video.hidden = false; });
  video.play().catch(() => { video.hidden = true; });
}
